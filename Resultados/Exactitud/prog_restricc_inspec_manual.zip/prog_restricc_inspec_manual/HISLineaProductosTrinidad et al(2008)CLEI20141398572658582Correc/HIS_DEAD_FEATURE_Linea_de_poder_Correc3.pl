:-use_module(library(clpfd)).
productline(L):-
L = [ADSL, Aparatos_control, Conexion_internet, Control, Fuego, HIS, Intrusion, Inundacion, Linea_de_poder, Luces, Servicio, Sistema_supervision, Temperatura, Video_sobre_demanda, WIFI],
L  ins 0..1,
Conexion_internet #= ((ADSL + Linea_de_poder) + WIFI),
(HIS #<==> Control),
(Aparatos_control #<==> Temperatura),
(Video_sobre_demanda + Conexion_internet) #=< (2 * Servicio),
HIS #= 1,
(1 * Servicio) #=< (Video_sobre_demanda + Conexion_internet),
Linea_de_poder #= 1,
(Sistema_supervision #<==> Fuego),
Intrusion #>= Inundacion,
(Control #<==> Luces),
(Sistema_supervision #<==> Intrusion),
HIS #>= Servicio,
Control #>= Aparatos_control,
(HIS #<==> Sistema_supervision),
labeling([ff], L).
