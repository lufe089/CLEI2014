:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, F5, F6, F7, F8, F9, Root],
L  ins 0..1,
(Root #<==> F2),
(F6 #<==> F7),
(F6 #<==> F9),
Root #= 1,
(Root #<==> F1),
((1 - F9) + (1 - F5)) #> 0,
(Root #<==> F4),
(1 * Root) #=< (F5 + F6),
(F5 + F6) #=< (2 * Root),
((1 - F4) + F8) #> 0,
((1 - F4) + (1 - F3)) #> 0,
((1 - F5) + (1 - F3)) #=< 0,
F6 #>= F8,
Root #>= F3,
labeling([ff], L).
