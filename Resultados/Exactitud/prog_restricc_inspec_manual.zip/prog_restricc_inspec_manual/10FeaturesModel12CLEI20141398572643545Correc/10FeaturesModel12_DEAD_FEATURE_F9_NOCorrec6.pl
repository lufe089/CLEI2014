:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, F5, F6, F7, F8, F9, Root],
L  ins 0..1,
((1 - F6) + (1 - F2)) #> 0,
(F1 #<==> F3),
(Root #<==> F1),
((1 - F3) + (1 - F9)) #> 0,
Root #>= F2,
F1 #= (F7 + F8),
Root #= 1,
F5 #>= F9,
F9 #= 1,
(1 * F1) #=< (F5 + F6),
((1 - F5) + F4) #> 0,
labeling([ff], L).
