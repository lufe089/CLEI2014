:-use_module(library(clpfd)).
productline(L):-
L = [F1, F10, F11, F12, F13, F14, F2, F3, F4, F5, F6, F7, F8, F9, Root],
L  ins 0..1,
((1 - F12) + (1 - F13)) #> 0,
(F3 #<==> F12),
((1 - F7) + F5) #=< 0,
(Root #<==> F2),
((1 - F7) + F14) #> 0,
(F3 #<==> F11),
Root #= 1,
Root #= (F7 + F8),
Root #= (F5 + F6),
Root #= (F9 + F10),
(F13 #<==> F14),
(Root #<==> F4),
(Root #<==> F1),
Root #>= F3,
labeling([ff], L).
