:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, Root],
L  ins 0..1,
Root #= 1,
((1 - F4) + F2) #> 0,
((1 - F4) + F3) #> 0,
F1 #>= F2,
F3 #= 0,
(1 * F1) #=< (F3 + F4),
(Root #<==> F1),
(F3 + F4) #=< (2 * F1),
labeling([ff], L).
