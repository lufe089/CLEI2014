:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, F5, F6, F7, F8, F9, Root],
L  ins 0..1,
Root #>= F2,
((1 - F4) + (1 - F9)) #> 0,
F9 #= 1,
F4 #>= F7,
(1 * Root) #=< (((F3 + F4) + F5) + F6),
Root #= 1,
F2 #>= F9,
((1 - F1) + F4) #> 0,
Root #>= F1,
((1 - F7) + (1 - F9)) #> 0,
((1 - F9) + F8) #> 0,
(((F3 + F4) + F5) + F6) #=< (4 * Root),
labeling([ff], L).
