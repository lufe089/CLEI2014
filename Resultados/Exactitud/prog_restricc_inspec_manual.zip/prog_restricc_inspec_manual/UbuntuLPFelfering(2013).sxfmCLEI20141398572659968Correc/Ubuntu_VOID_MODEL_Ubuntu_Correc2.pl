:-use_module(library(clpfd)).
productline(L):-
L = [Bash, Editor_texto, GUI, Gedit, Glchess, Gnome, Gnuchess, Juegos, KDE, Ubuntu, Vi],
L  ins 0..1,
((1 - Bash) + (1 - GUI)) #> 0,
((1 - Editor_texto) + (1 - Bash)) #> 0,
Ubuntu #>= Juegos,
Ubuntu #= 1,
(Ubuntu #<==> Bash),
(1 * GUI) #=< (KDE + Gnome),
((1 - Juegos) + GUI) #> 0,
(Vi + Gedit) #=< (2 * Editor_texto),
Juegos #= (Gnuchess + Glchess),
(KDE + Gnome) #=< (2 * GUI),
(1 * Editor_texto) #=< (Vi + Gedit),
labeling([ff], L).
