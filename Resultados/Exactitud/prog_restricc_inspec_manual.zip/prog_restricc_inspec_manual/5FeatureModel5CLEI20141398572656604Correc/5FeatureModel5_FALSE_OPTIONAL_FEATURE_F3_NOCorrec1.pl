:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, Root],
L  ins 0..1,
F3 #= 0,
(1 * Root) #=< (F3 + F4),
(F3 + F4) #=< (2 * Root),
Root #>= F2,
(Root #<==> F1),
Root #= 1,
((1 - F4) + F3) #> 0,
((1 - F2) + F1) #> 0,
labeling([ff], L).
