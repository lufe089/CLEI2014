:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, Root],
L  ins 0..1,
Root #>= F1,
((1 - F3) + (1 - F4)) #=< 0,
Root #= 1,
((1 - F2) + (1 - F1)) #> 0,
(Root #<==> F2),
(Root #<==> F3),
labeling([ff], L).
