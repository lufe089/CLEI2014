:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, Root],
L  ins 0..1,
Root #>= F1,
((1 - F3) + (1 - F4)) #> 0,
F4 #= 1,
Root #= 1,
(Root #<==> F2),
(F1 #<==> F4),
(Root #<==> F3),
labeling([ff], L).
