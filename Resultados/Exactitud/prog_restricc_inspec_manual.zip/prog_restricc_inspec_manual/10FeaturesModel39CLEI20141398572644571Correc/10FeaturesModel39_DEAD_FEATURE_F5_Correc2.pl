:-use_module(library(clpfd)).
productline(L):-
L = [F1, F2, F3, F4, F5, F6, F7, F8, F9, Root],
L  ins 0..1,
Root #= (F3 + F4),
F5 #= 1,
(Root #<==> F2),
(1 * F1) #=< (F6 + F7),
F1 #>= F5,
((1 - F8) + F2) #> 0,
((1 - F5) + (1 - F4)) #> 0,
((1 - F6) + (1 - F8)) #> 0,
(Root #<==> F1),
F1 #= (F8 + F9),
Root #= 1,
(F6 + F7) #=< (2 * F1),
labeling([ff], L).
