import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.cfm.productline.main.MainDefectAnalyzer;


public class Main1 {

	public static void main(String[] args) {
		try {
			String modelName = "";
			String modelPath = "";
			String outputPath = "";
			System.out.print("Introduzca el nombre del modelo ");
			BufferedReader entrada = new BufferedReader(new InputStreamReader(
					System.in));
			modelName = entrada.readLine();
			System.out.print("Introduzca la ruta completa del modelo ");
			modelPath = entrada.readLine();
			System.out
					.print("Introduzca la ruta completa del directorio de salida ");
			outputPath = entrada.readLine();
			
			MainDefectAnalyzer defectAnalyzer = new MainDefectAnalyzer();
			defectAnalyzer.analyzeSplotFM(modelName, modelPath, outputPath);
			System.out.println("El modelo se analiz� correctamente");

		} catch (Exception e) {
			System.out.println("Ocurrio el siguiente error");
			e.printStackTrace();
		}

	}

}
